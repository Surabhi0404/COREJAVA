import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

enum Gen{
	M, F;
}
public class Person {
	String firstname;
	String lastname;
	String gender;
	Gen gen;
	public Person() {
		System.out.println("WELCOME");
	}
	public Person(String firstname, String lastname, String gender) {
		//super();
		this.firstname = firstname;
		this.lastname = lastname;
		setGender(gender);
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public Gen getGender() {
		return gen;
	}
	public void setGender(String gender) {
		if(gender.equals("Male"))
		gen =Gen.M;
		else gen=Gen.F;
	}
	@Override
	public String toString() {
		return "Person Details:"+"\nfirstname=" + firstname + "" +
				" \nlastname=" + lastname+" Gender:"+gen;
	}
				
	
	public void phone(String...i){
		for(String p:i){
			System.out.println(p);
			
		}
			
	}
	public int calculateAge(String dob) throws ParseException {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		Calendar age = Calendar.getInstance();
		age.setTime(sdf.parse(dob));
		Calendar today = Calendar.getInstance();
		int curYear = today.get(Calendar.YEAR);
		int dobYear = age.get(Calendar.YEAR);
		
		return curYear - dobYear;
	}
	public String getFullName(String firstName, String lastName){
		return firstName+" "+lastName;
	}
	

}
