import java.text.ParseException;
import java.util.Scanner;


public class PersonMain {
	public static void main(String[] args) throws ParseException {
		Person p=new Person("XYZ", "ABC", "Male" );
		p.phone("9888","4445555","4444");
		System.out.println(p);
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		System.out.println(p.calculateAge(input));
		System.out.println("Enter f and l name");
		String fname=scanner.nextLine();
		String lname=scanner.nextLine();
		System.out.println(p.getFullName(fname, lname));
		scanner.close();
		//Person p[]=new Person[3];
		//Person p1=new Person();
		//Scanner sc=new Scanner(System.in);
		//int n=3;
		/*System.out.println("Print details of 3");
		
		for(int i=0; i<3; i++){
			p[i]=new Person(sc.next(), sc.next(),sc.next().charAt(0));
			
		}*/
		
		/*for (Person obj:p){
			obj=new Person(sc.next(), sc.next(),sc.next().charAt(0));
			//obj.phone(sc.next());
		}
		System.out.println(p[2].firstname);*/
		
		/*for (Person obj:p)
			System.out.println(obj);	
		sc.close();*/
		//System.out.println(p);
	}
}
