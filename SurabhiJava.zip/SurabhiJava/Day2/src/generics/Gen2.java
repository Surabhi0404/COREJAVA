package generics;

 class Gen2<T> extends Gen<T> {

	Gen2(T obj) {
		super(obj);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Gen2 [obj=" + obj + ", getObject()=" + getObject()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
}
