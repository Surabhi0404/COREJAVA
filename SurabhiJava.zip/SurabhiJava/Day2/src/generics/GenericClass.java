package generics;

class Gen<T>{
	T obj;

	public Gen(T obj) {
		super();
		this.obj = obj;
	}
	T getObject(){
		return obj;
	}
	@Override
	public String toString() {
		return "Gen [obj=" + obj + "]";
	}
	
}
