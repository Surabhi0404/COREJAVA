package scanners;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Demo {
	public static void main(String[] args) throws FileNotFoundException {
		File file=new File("C:/deleteme/abc.txt");
		Scanner scan=new Scanner(file);
		String str;
		while (true) {
			try {
				str=scan.nextLine();
			} catch (Exception e) {
				// TODO: handle exception
				break;
			}
			System.out.println("Next Line is"+str);
		}
	}

}
