package presentationlogic;

import java.util.InputMismatchException;
import java.util.Scanner;




public class presentationlogic {
Scanner sc;

	

	public void printdata(pojo myobject) {
		System.out.println("below are the values");
		System.out.println(myobject);
		// TODO Auto-generated method stub
		
	}

	public pojo acceptdata() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		pojo obj=new pojo();
		try {
			System.out.println("enter a no");
			obj.setNum(sc.nextInt());
		}
		catch(InputMismatchException e)
		{
			System.out.println("it needs a number pls enter");
			obj=acceptdata();
		}
		return obj;
	
		
	}

	

}