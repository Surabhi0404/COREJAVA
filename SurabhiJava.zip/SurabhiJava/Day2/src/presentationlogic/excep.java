package presentationlogic;
import java.util.Scanner;



public class excep {
public static void main(String[] args)
{presentationlogic presentation=new presentationlogic();
pojo myobject=null;
myobject=presentation.acceptdata();

Businesslogic business=new Businesslogic(myobject);
myobject=business.calculate();
presentation.printdata(myobject);

	

}
}

