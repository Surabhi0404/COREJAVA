package presentationlogic;

public class pojo{
	

	int num,result;
	

	@Override
	public String toString() {
		return "pojo [num=" + num + ", result=" + result + "]";
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}

	

	
	}
