package presentationlogic;

public class Businesslogic {

	private pojo myobject;
	


	public Businesslogic(pojo myobject) {
		//super();
		this.myobject = myobject;
	}



	public pojo calculate() {
		myobject.setResult(1000/myobject.getNum());
		return myobject;
		// TODO Auto-generated method stub
	
	}

}
