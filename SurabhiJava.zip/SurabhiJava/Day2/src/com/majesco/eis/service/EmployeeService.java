package com.majesco.eis.service;

public interface EmployeeService {
	void adddetails();
	void details();
	void insurancescheme();
	

}
