package com.majesco.eis.service;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import com.majesco.eis.bean.Employee;
import com.majesco.eis.exception.EmployeeException;

public class Service implements EmployeeService, Comparable{
	Employee e=new Employee();
	HashMap<Integer, Employee> list =new HashMap<>();
	static int n;

	@Override
	public void adddetails() {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("How many employees?");
		n=sc.nextInt();
		for(int i=0; i<n; i++){
		System.out.println("Add details:id, name, salary, designation");
		e=new Employee(sc.nextInt(), sc.next(), sc.nextInt(), sc.next());
		
		list.put(e.getId(), e);
		try {
			if(e.getSalary()<3000)
			throw new EmployeeException();
		} catch (EmployeeException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
			adddetails();
		}
		
		}
		
	}

	@Override
	public void details() {
		// TODO Auto-generated method stub
		Set set = list.entrySet();
		Iterator i =set.iterator();
		while (i.hasNext()) {
			Map.Entry me = (Map.Entry) i.next();
			System.out.println(me.getKey() + ": " + me.getValue());
			insurancescheme();
			System.out.println(e.getInsurancescheme());
		}
		
		/*insurancescheme();
		System.out.println(e.getInsurancescheme());*/
		
		
	}

	@Override
	public void insurancescheme() {
		// TODO Auto-generated method stub
		//System.out.println(e);
		if(e.getSalary()>5000&&e.getSalary()<20000&&e.getDesignation().equals("System Associate"))
			e.setInsurancescheme("Scheme C");
		if(e.getSalary()>=20000&&e.getSalary()<4000&&e.getDesignation().equals("Programmer"))
			e.setInsurancescheme("Scheme B");
		if(e.getSalary()>=40000&&e.getDesignation().equals("Manager"))
			e.setInsurancescheme("Scheme A");
		if(e.getSalary()<5000&&e.getDesignation().equals("Clerk"))
			e.setInsurancescheme(null);				
	}
	public boolean deleteEmployee(int id) {
		for(int i=1; i<=n; i++ ){
		if(e.getId()==id)
		list.remove(id);
	}
		return true;
		
	}

	@Override
	public int compareTo(Object arg0) {
		// TODO Auto-generated method stub
		if(this.e.getSalary()==((Employee) arg0).getSalary())
		return 0;
		else if(this.e.getSalary()>((Employee) arg0).getSalary())
			return +1;
		else return -1;
	}
	
 

}
