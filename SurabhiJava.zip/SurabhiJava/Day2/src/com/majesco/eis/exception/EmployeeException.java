package com.majesco.eis.exception;

public class EmployeeException extends Exception{
	//Employee e;
	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Salary cannot be less than 3000";
	}
	
	
	

}
