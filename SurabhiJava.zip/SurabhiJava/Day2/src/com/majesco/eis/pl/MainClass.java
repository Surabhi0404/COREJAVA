package com.majesco.eis.pl;

import java.util.Scanner;

import com.majesco.eis.bean.Employee;
import com.majesco.eis.service.Service;

public class MainClass {
	static Employee e;
	public static void main(String[] args) {
		Service s=new Service();
		
		s.adddetails();
		s.details();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id of employee to delete");
		int i=sc.nextInt();
		if(s.deleteEmployee(i)==true)
			s.details();
		
		s.compareTo(e);
		s.details();
		
	}
	

}
