import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;


public class DateConverter {

	public static void main(String[] args) throws ParseException {
		System.out.println("Please enter date in following format :");
		//specify format to be used in simple date formatter
		System.out.println("dd/mm/yyyy");
		Scanner sc=new Scanner(System.in);
		String mydate=sc.next();
		
		SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
		
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(mydate));

		//conversion to util date
		java.util.Date d=c.getTime();
		System.out.println("UTIL DATE IS "+d);
		
		//conversion from util date to sql date
		java.sql.Date d1=new java.sql.Date(d.getTime());
		System.out.println("SQL DATE IS "+d1);
		
		//conversion from sql date to util date
		System.out.println("Getting back util date");
		d=new java.util.Date(d1.getTime());
		System.out.println(d);
		
	}
	
}
