package money;

public class SavingsAccount extends Account{
	final double minimumBalance=500;

	@Override
	boolean withdraw(double wd) {
		// TODO Auto-generated method stub
		if (getBalance()<minimumBalance)
			return false;
		else return true;
		
	}

}
