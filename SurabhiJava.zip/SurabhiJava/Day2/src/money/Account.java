package money;

public abstract class Account{
	static int i;
	long accNum;
	double balance=500;
	Person accHolder;
	
	void desposit(double dep){
		balance=getBalance()+dep;
	}
	abstract boolean withdraw(double wd);
		
	double getBalance(){
		return balance;
	}
	public long getAccNum() {
		i++;
		return i;
	}
	/*public void setAccNum(long accNum) {
		this.accNum = accNum;
	}*/
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accNum=" + getAccNum() + ", balance=" + balance
				+" "+ accHolder + "]";
	}
	
	
}
