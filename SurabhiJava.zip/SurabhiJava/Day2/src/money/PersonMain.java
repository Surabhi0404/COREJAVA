package money;

//import java.util.Scanner;

public class PersonMain{
	public static void main(String[] args) {
		//Scanner sc= new Scanner(System.in);
		
		Account smith=new SavingsAccount();
		smith.setBalance(2000);
		Account kathy=new CurrentAccount();
		kathy.setBalance(3000);
		if(smith.withdraw(2000)==true)
			smith.balance=smith.getBalance()-2000;
		else System.out.println("Limit reached");
		if(kathy.withdraw(2000)==true)
			kathy.balance=kathy.getBalance()-2000;
		else System.out.println("Limit reached");
		Person p1=new Person("Smith", 20);
		Person p2=new Person("Kathy", 22);
		smith.setAccHolder(p1);
		kathy.setAccHolder(p2);
		System.out.println(smith);
		System.out.println(kathy);
		
	}
	

}
