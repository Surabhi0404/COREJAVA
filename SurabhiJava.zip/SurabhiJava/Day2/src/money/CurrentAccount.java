package money;

public class CurrentAccount extends Account {
	final double overdraftLimit=getBalance();

	@Override
	boolean withdraw(double wd) {
		// TODO Auto-generated method stub
		if (wd>overdraftLimit) 
			return false;
		else
			return true;
	}
	
}
