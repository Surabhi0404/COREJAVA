package dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

class Retrieval{
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select * FROM EMP23");
		//while (rs.next()) {
		/*rs.last();
		rs.previous();*/
		rs.absolute(2);
			System.out.println(rs.getInt(1)+"\t"+rs.getString("ename"));
			
		//}
		conn.close();

	}
}