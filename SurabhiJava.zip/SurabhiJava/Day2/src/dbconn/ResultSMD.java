package dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

public class ResultSMD {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM mobiles");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
		conn.close();
	}
	

}
