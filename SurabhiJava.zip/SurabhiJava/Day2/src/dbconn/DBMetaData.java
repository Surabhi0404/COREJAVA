package dbconn;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBMetaData {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		//ResultSet rs=stmt.executeQuery("Select * FROM EMP23");
		DatabaseMetaData dbmd=conn.getMetaData();
		System.out.println(dbmd.getDatabaseProductName());
		System.out.println(dbmd.getDriverName());

	}

}
