package dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Create {
	public static void main(String[] args) throws SQLException {
		//Class.forName("oracle.jdbc.driver.OracleDriver"); to be used when you have to select driver from property files
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//google java driver for oracle xe connection string for driver name
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		boolean b=stmt.execute("create table insured(Insuredid number, Name varchar2(20), Age number, Premium number, Coveragelimit number)");
		System.out.println(b);
		//stmt.execute("drop table EMP23");
		conn.close();
		
	}

}
