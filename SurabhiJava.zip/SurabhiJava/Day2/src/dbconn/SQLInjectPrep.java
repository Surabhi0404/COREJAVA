package dbconn;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.net.aso.r;

class SQLInjectPrep{
	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException {
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		PreparedStatement stmt=conn.prepareStatement("SELECT username, password FROM uspass WHERE username=? and password=?");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter Username:");
		String username=br.readLine();
		System.out.println("Enter Password:");
		String password=br.readLine();
		//String query="SELECT username, password FROM uspass WHERE username='"+username+"'and password='"+password+"'";
		//System.out.println(query);
		stmt.setString(1, username);
		stmt.setString(2, password);
		int cnt=stmt.executeUpdate();
		System.out.println(cnt);
		if(cnt>=1)
			System.out.println("Welcome,....");
		else System.out.println("NOT ALLOWED");
			
		


		/*ResultSet rs=stmt.executeQuery("Select empid, ename FROM EMP23");
		//while (rs.next()) {
		rs.last();
		rs.previous();*/
		//rs.absolute(2);
	/*	int empno=0;
		String ename=null;
		while (rs.next()) {
			empno=rs.getInt("empid");
			ename=rs.getString("ename");
			if(empno%2==0){
				rs.moveToCurrentRow();
				rs.updateString(2, ename+empno);
				rs.updateRow();
			}
		}*/

			//System.out.println(rs.getInt(1)+"\t"+rs.getString("ename"));
			
		//}
		conn.close();

	}
}