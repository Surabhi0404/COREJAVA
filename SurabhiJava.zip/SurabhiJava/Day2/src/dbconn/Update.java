package dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.net.aso.r;

class Update{
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		Class.forName("oracle.jdbc.driver.OracleDriver"); 
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select empid, ename FROM EMP23");
		//while (rs.next()) {
		/*rs.last();
		rs.previous();*/
		//rs.absolute(2);
		int empno=0;
		String ename=null;
		while (rs.next()) {
			empno=rs.getInt("empid");
			ename=rs.getString("ename");
			if(empno%2==0){
				rs.moveToCurrentRow();
				rs.updateString(2, ename+empno);
				rs.updateRow();
			}
		}

			//System.out.println(rs.getInt(1)+"\t"+rs.getString("ename"));
			
		//}
		conn.close();

	}
}