package files;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;



public class Reverse {
	public static void main(String[] args) throws IOException {
		FileReader fr=new FileReader("C:/deleteme/a.txt");
		File file=new File("C:/deleteme/b.txt");
		file.createNewFile();
		FileWriter fw=new FileWriter(file);
		BufferedReader br=new BufferedReader(fr);
		String data;
		String reverse;
		while ((data=br.readLine())!=null) {
			System.out.println(data);
			String[] words = data.split(" ");
		    for(String a: words){
		        StringBuilder builder=new StringBuilder(a);
		        System.out.print(builder.reverse().toString());
			
			
		}
		
		
	}
		
	}

}

