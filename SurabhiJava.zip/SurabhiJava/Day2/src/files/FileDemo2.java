package files;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;

public class FileDemo2 {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		File file=new File("C:/deleteme/abc.txt");
		
		FileInputStream fis=new FileInputStream(file);
		ObjectInputStream ois=new ObjectInputStream(fis);
		
		Object yourobj=ois.readObject();
		if(yourobj instanceof FileDemo){
			FileDemo FileDemo=(FileDemo)yourobj;
			System.out.println(FileDemo);
			System.out.println("You passed FileDemo");
			
		}
		else if(yourobj instanceof EmpObjectSerializationDemo){
			EmpObjectSerializationDemo pj=(EmpObjectSerializationDemo) yourobj;
			System.out.println(pj );
			System.out.println("Your object is of EmpObjectSerializationDemo");
					
		}
		else
			System.out.println("Empty");
		ois.close();
		fis.close();
		System.out.println("Done");
	}

}
