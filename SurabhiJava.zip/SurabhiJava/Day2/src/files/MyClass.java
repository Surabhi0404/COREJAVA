package files;
import java.util.Scanner;

public class MyClass{
	public static void main(String[] args) {
		int n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Input a number");
		n=sc.nextInt();
		if(n<0)
			System.out.println("Negative");
		else if (n>0)
			System.out.println("Positive");
		else
			System.out.println("cannot be determined");
	}
}