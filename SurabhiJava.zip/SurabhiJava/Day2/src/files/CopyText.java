package files;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class CopyText {
	FileInputStream fromfile;
	FileOutputStream tofile;
	void init(String str1, String str2){
		try {
			fromfile =new FileInputStream(str1);
			tofile=new FileOutputStream(str2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			
			System.out.println("Exception:"+e);
			return;
		}
		
	}
	public void copyContents() {
		
	}

}

