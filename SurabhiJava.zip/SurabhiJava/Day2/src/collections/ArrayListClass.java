package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ArrayListClass {
	public static void main(String[] args) {
		ArrayList<String> al=new ArrayList<String>();
		System.out.println("Initial size of al: "+al.size());
		al.add("USB");
		al.add("Floppy");
		al.add("CD");
		al.add("DVD");
		al.add("VCR");
		Collections.sort(al);
		for(String i:al)
			System.out.println(i);
		/*Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			Object element = itr.next();
			System.out.println(element + "\n");
		}*/
		System.out.println("Final size of al: "+al.size());
	}
	

}
