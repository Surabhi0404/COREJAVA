package exception;

import java.util.Scanner;

public class MyClass {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Input age");
		MyAge age= new MyAge(sc.nextInt());
		if(age.age<15){
			try {
				throw new AgeExcept(age);
			} catch (AgeExcept e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				main(null);
			}
			
		}
		else
			System.out.println(age.getAge()+"is above 15");
		
	}

}
