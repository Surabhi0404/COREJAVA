package exception;

public class AgeExcept extends Exception {
	MyAge age;
	public AgeExcept(MyAge age){
		msg();
	}
	private void msg() {
		// TODO Auto-generated method stub
		System.out.println("Age should be above 15");
	}
	
		
	

}
