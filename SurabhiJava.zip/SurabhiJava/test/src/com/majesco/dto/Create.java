package com.majesco.dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import com.majesco.conlog.ConnectionFactory;
public class Create {
	static Connection conn=ConnectionFactory.getConn();
	public static void main(String[] args) throws SQLException {
		//Class.forName("oracle.jdbc.driver.OracleDriver"); to be used when you have to select driver from property files
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//google java driver for oracle xe connection string for driver name
		//Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		boolean b=stmt.execute("create table EmployeeNew2(Empno NUMBER, Ename VARCHAR2 (20), Dob Date)");
		//boolean c=stmt.execute("CREATE TABLE purchasedetails(purchaseid NUMBER, cname vARCHAR2(20), mailid VARCHAR2(30),phoneno VARCHAR2(20), purchasedate DATE, mobileid references mobiles(mobileid))");
		System.out.println(b);
		//System.out.println(c);
		//stmt.execute("drop table Employee");
		conn.close();
		
	}

}
