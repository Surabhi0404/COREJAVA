package com.majesco.dto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.majesco.annot.IGate_MethodInfo;
import com.majesco.conlog.ConnectionFactory;
import com.majesco.inter.OperationsInterface;

public class Operations implements OperationsInterface {
	Connection conn=ConnectionFactory.getConn();
	static Statement stmt;
	static Pojo pp;
	static HashSet<Pojo> hs = new HashSet<Pojo>();
	@IGate_MethodInfo(purpose = "Inserting into the table")
	public Pojo insertpojo(Pojo pp) throws SQLException{
		//Date date = new Date("DD-MM-YYY");
		Iterator<Pojo> itr = hs.iterator(); // make an iterator
		while (itr.hasNext()) {
			 pp = itr.next(); // cast not required
			
		 
		PreparedStatement pst=conn.prepareStatement("Insert into EmployeeNew2 values (?,?,?)");
		pst.setInt(1, pp.empno);
		pst.setString(2, pp.ename);
		pst.setDate(3, pp.dob);
		int i=pst.executeUpdate();
		System.out.println(i);
		
	
		}
		return pp;
	
	}
	
	
	@IGate_MethodInfo(purpose = "Disaply the EmployeeNew1 table")
	public void displaytable(Pojo obj) throws SQLException {
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM EmployeeNew2");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
	
		
	}
	/*public boolean mobid(Pojo pp) throws SQLException{
		stmt=conn.createStatement();
		int i=stmt.executeUpdate("Select * FROM mobiles where mobileid="+pp.getMobileid());
		if(i>0){
			conn.commit();
			return true;}
		else return false;
	}*/
	public void select(Pojo pp) throws SQLException{
		stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select Empno, Ename, Dob FROM Employees");
		int empno=0;
		String ename=null;
		java.sql.Date dob=null;
		while(rs.next()){
		empno=rs.getInt("empno");
		ename=rs.getString("ename");
		dob=rs.getDate("dob");
		/*pp.setEmpno(empno);
		pp.setEname(ename);
		pp.setDob(dob);*/
		pp=new Pojo(empno, ename, dob); 
		//HashSet hs = new HashSet();
		hs.add(pp);
		
			
		}
		
		
		
	
	}



	



	
	

}
