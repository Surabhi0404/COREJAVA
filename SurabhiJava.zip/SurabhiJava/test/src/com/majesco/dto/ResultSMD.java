package com.majesco.dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import com.majesco.conlog.ConnectionFactory;

public class ResultSMD {
	static Connection conn=ConnectionFactory.getConn();

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//Class.forName("oracle.jdbc.driver.OracleDriver"); 
		//Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM EmployeeNew");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
		conn.close();
	}
	

}
