package com.majesco.dto;

import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;

public class Pojo {
	int empno;
	String ename;
	java.sql.Date dob;
	public Pojo(int empno, String ename, java.sql.Date dob2) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.dob = dob2;
	}
	
	public Pojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getEmpno() {
		return empno;
	}
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public java.sql.Date getDob() {
		return dob;
	}
	public void setDob(java.sql.Date dob) {
		this.dob = dob;
	}
	@Override
	public String toString() {
		return "Pojo [empno=" + empno + ", ename=" + ename + ", dob=" + dob
				+ "]";
	}
		
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return empno;
	}

	@Override
	public boolean equals(Object obj) {
		if (obj == null) return false;
	    if (!(obj instanceof Pojo))
	        return false;
	    if (obj == this)
	        return true;
	    return this.getEmpno() == ((Pojo) obj).getEmpno();
	}
	
	

}
