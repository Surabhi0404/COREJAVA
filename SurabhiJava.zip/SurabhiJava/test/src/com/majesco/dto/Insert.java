package com.majesco.dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.majesco.conlog.ConnectionFactory;

public class Insert {
	static Connection conn=ConnectionFactory.getConn();
	static Statement stmt;
	public static void main(String[] args) throws SQLException {
		//Class.forName("oracle.jdbc.driver.OracleDriver"); to be used when you have to select driver from property files
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//google java driver for oracle xe connection string for driver name
		//Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		Statement stmt=conn.createStatement();
		/*boolean b=stmt.execute("create table Emp23(EMPID number(3) primary key, Ename varchar2(20))");
		System.out.println(b);
		//stmt.execute("drop table EMP23");
*/		
		//System.out.println(stmt.executeQuery("SELECT * FROM EMP23"));
		//Scanner sc=new Scanner(System.in);
		//System.out.println("Enter empno and name");
		//int empno=sc.nextInt();
		//String name=sc.next();
		//int i=stmt.executeUpdate("Insert into Employees values(4, 'LIGHT', TO_DATE('04/02/1987', 'DD/MM/YYYY'))");
		//int i=stmt.executeUpdate("INSERT INTO Employee(Dob) VALUES(TO_DATE('04/04/1996', 'DD/MM/YYYY'))");
		//System.out.println("Value of i is "+i);
		conn.commit();
		conn.close();
		
		
	}

}
