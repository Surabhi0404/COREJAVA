package com.majesco.main;

import java.sql.SQLException;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import com.majesco.annot.IGate_MethodInfo;
import com.majesco.conlog.MyLogger;
import com.majesco.dao.BusinessLogic;
import com.majesco.dao.PresentationLogic;


import com.majesco.dto.Operations;
import com.majesco.dto.Pojo;


public class Executor {
	static Logger logger=MyLogger.getMyLogger();
	@IGate_MethodInfo(purpose = "This is the main class")
	public static void main(String[] args) throws SQLException {
		BasicConfigurator.configure();
		Pojo pp=new Pojo();
		Operations op=new Operations();
		op.select(pp);
		PresentationLogic plogic=new PresentationLogic();
		BusinessLogic blogic=new BusinessLogic();
		blogic.blinsert(op, pp);
		plogic.display(op, pp);
		logger.info("CLOSE");
		
		
	}

}
