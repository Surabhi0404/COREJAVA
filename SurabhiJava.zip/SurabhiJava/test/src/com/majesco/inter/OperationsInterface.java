package com.majesco.inter;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import com.majesco.dto.Pojo;





public interface OperationsInterface {
	public Pojo insertpojo(Pojo pp) throws SQLException;
	public void displaytable(Pojo obj) throws SQLException;
	public void select(Pojo pp) throws SQLException;
}
