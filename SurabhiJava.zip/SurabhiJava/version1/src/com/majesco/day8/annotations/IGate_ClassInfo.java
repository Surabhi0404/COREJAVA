package com.majesco.day8.annotations;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface IGate_ClassInfo {
	String author() default "Pravin";
	String purpose();
	String parentHierarchyInfo() default "none";
	String childHierarchyInfo() default "none";
}
