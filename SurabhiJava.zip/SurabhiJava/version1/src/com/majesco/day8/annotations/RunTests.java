package com.majesco.day8.annotations;
import java.lang.reflect.*;
public class RunTests {
    public static void main(String[] args) throws Exception {
          int total= 0;
          for (Method m : Class.forName("com.majesco.dto.InsuredMain").getMethods()){    
                if (m.isAnnotationPresent(IGate_MethodInfo.class)) {
                     //m.invoke(null);
                     total++; 
                 } 
            }
      System.out.println("No:of:methods with Annotation :"+total); 
} }

