package com.majesco.dto;
import com.majesco.day8.annotations.IGate_ClassInfo;
import com.majesco.day8.annotations.IGate_MethodInfo;

import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.majesco.logger.MyClass;
@IGate_ClassInfo(purpose = "Hello")
public class InsuredMain {
	
	static Insured obj;
	static DBOperations dbo=new DBOperations();
	@IGate_MethodInfo(purpose = "Hello")
	public static void main(String[] args) throws SQLException {
		//DBOperations dbo=new DBOperations();
		PresentationLogic pl=new PresentationLogic();
		Validate val=new Validate();
		//Insured obj=pl.addetails();
		//val.valid(obj);
		//boolean t=val.valid(obj);
		//System.out.println(t);
				
		//dbo.insert(obj);
		
		//else System.out.println("Cannot insert! Enter valid name");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 1 to insert, 2 to update and 3 to delete");
		int i=sc.nextInt();
		if(i==1){
			obj=pl.addetails();
			val.valid(obj);
			System.out.println("Done");
			dbo.displaytable(obj);
			
		}
		if(i==2){
		dbo.update(obj);
		System.out.println("Done");
		dbo.displaytable(obj);
		}
		
		else if(i==3){
			dbo.delete(obj);
			System.out.println("Done");
			dbo.displaytable(obj);
		}
		else{
			System.out.println("Enter valid choice");
			main(null);
		}
	}

}
