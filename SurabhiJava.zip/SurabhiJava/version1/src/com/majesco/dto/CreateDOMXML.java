package com.majesco.dto;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.w3c.dom.*;

import com.majesco.doa.ConnectionFactory;

import javax.xml.parsers.*; 
import javax.xml.transform.*; 
import javax.xml.transform.dom.DOMSource; 
import javax.xml.transform.stream.StreamResult; 


public class CreateDOMXML 
{
	static Connection conn=ConnectionFactory.getConn();

  public static void main(String[] args) 
  {
    try{
    //Create instance of DocumentBuilderFactory
    DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    //Get the DocumentBuilder
    DocumentBuilder docBuilder = factory.newDocumentBuilder();
    //Create blank DOM Document
        Document doc = docBuilder.newDocument();
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());

        Statement stmt=conn.createStatement();

        ResultSet rs=stmt.executeQuery("Select * FROM Insured");

    //create the root element
        Element root = doc.createElement("Insureds");
    //all it to the xml tree
        doc.appendChild(root);
    
      //create a comment
      Comment comment = doc.createComment("This is comment");
      //add in the root element
      root.appendChild(comment);

    //create child element
      while(rs.next()){
    Element insured = doc.createElement("Insured");
    //Add the atribute to the child
    insured.setAttribute("InsuredID",rs.getString("insuredid"));
    
    Element name = doc.createElement("name");
    Text nametxt=doc.createTextNode(rs.getString("name"));
    name.appendChild(nametxt);
    insured.appendChild(name);
    
    Element age=doc.createElement("age");
    Text agetxt=doc.createTextNode(rs.getString("age"));
    age.appendChild(agetxt);
    insured.appendChild(age);
    
    root.appendChild(insured);
    
      }
    root.normalize();
    

   TransformerFactory tranFactory = TransformerFactory.newInstance(); 
    Transformer aTransformer = tranFactory.newTransformer(); 

    Source src = new DOMSource(doc); 
    FileOutputStream output =new FileOutputStream("C:/deleteme/insureds.xml");
    Result dest = new StreamResult(output); 
    aTransformer.transform(src, dest); 


    }catch(Exception e){
      System.out.println(e.getMessage());
    }


  }
} 