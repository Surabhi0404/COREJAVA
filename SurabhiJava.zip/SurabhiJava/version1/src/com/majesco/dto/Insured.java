package com.majesco.dto;

public class Insured {
	int insuredid;
	String name;
	int age;
	double premium;
	double coveragelimit;
	public Insured(int insuredid, String name, int age, double premium,
			double coveragelimit) {
		super();
		this.insuredid = insuredid;
		this.name = name;
		this.age = age;
		this.premium = premium;
		this.coveragelimit = coveragelimit;
	}
	public int getInsuredid() {
		return insuredid;
	}
	public void setInsuredid(int insuredid) {
		this.insuredid = insuredid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getPremium() {
		return premium;
	}
	public void setPremium(double premium) {
		this.premium = premium;
	}
	public double getCoveragelimit() {
		return coveragelimit;
	}
	public void setCoveragelimit(double coveragelimit) {
		this.coveragelimit = coveragelimit;
	}
	@Override
	public String toString() {
		return "Insured [insuredid=" + insuredid + ", name=" + name + ", age="
				+ age + ", premium=" + premium + ", coveragelimit="
				+ coveragelimit + "]";
	}
	

}
