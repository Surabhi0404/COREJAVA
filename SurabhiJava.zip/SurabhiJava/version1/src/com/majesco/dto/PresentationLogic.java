package com.majesco.dto;

import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class PresentationLogic {
	int id;
	String name;
	int age;
	double premium;
	double cvl;
	Insured addetails() throws SQLException{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id,name, age, premium, coveragelimit ");
		
		try {
			id = sc.nextInt();
			name = sc.next();
			age = sc.nextInt();
			premium = sc.nextDouble();
			cvl = sc.nextDouble();
		} catch (InputMismatchException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter valid data");
			InsuredMain.main(null);
			e.printStackTrace();
		}
		Insured obj=new Insured(id, name, age, premium, cvl);
		return obj;
	}

}
