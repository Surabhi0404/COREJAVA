package com.majesco.dto;

import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.majesco.excep.NameException;
import com.majesco.logger.MyClass;

public class Validate {
	Logger logger=MyClass.getMyLogger();
	 void valid(Insured obj) throws SQLException{
		 DBOperations dbo=new DBOperations();
		 String name=obj.getName();
		String pattern="[A-Za-z][A-Za-z]+";
		String id=String.valueOf(obj.getInsuredid());
		String patternid="\\d+";
		boolean patternmatched=Pattern.matches(pattern, name);	
		boolean patternmatchedid=Pattern.matches(patternid, id);
		/*boolean patternmatchedage=Pattern.matches(patternid, String.valueOf(obj.getAge()));
		boolean patternmatchedprem=Pattern.matches(patternid, String.valueOf(obj.getPremium()));
		boolean patternmatchedcvl=Pattern.matches(patternid, String.valueOf(obj.getCoveragelimit()));*/
		//if(patternmatched==false||patternmatchedid==false||patternmatchedage==false||patternmatchedprem==false||patternmatchedcvl==false){
		if(patternmatched==false||patternmatchedid==false){	
		try {
				throw new NameException();
			} catch (NameException e) {
				// TODO Auto-generated catch block
				//System.out.println(e.getMessage());
				logger.error(e.getMessage());
				InsuredMain.main(null);
				e.printStackTrace();
			}
		}
		else dbo.insert(obj);
		


}
	 
}