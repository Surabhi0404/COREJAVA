package com.majesco.dto;

import java.sql.SQLException;


public interface DBOperationsInterface {
	public Insured insert(Insured obj) throws SQLException;

}
