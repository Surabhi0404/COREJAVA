package com.majesco.dto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.majesco.doa.ConnectionFactory;

public class DBOperations implements DBOperationsInterface{
	Connection conn=ConnectionFactory.getConn();
	static Statement stmt;
	

	@Override
	public Insured insert(Insured obj) throws SQLException {
		// TODO Auto-generated method stub
		PreparedStatement pst=conn.prepareStatement("Insert into insured values (?,?,?,?,?)");
		pst.setInt(1, obj.getInsuredid());
		pst.setString(2, obj.getName());
		pst.setInt(3,obj.getAge());
		pst.setDouble(4, obj.getPremium());
		pst.setDouble(5, obj.getCoveragelimit());
		int i=pst.executeUpdate();
		return obj;
	}
	
	public Insured update(Insured obj) throws SQLException {
		stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select name, age, premium, coveragelimit FROM insured");
		while (rs.next()) {
			int age = rs.getInt("age");
			int coveragelimit = rs.getInt("coveragelimit");
			if(age<=18||age>=60){
				rs.moveToCurrentRow();
				rs.updateString(4, String.valueOf(coveragelimit+500));
				rs.updateRow();
			}
		
		
		
	}
		return obj;

	}
	public Insured delete(Insured obj) throws SQLException {
		stmt=conn.createStatement();
		 ResultSet rs=stmt.executeQuery("Delete FROM insured WHERE age>110");
    
	return obj;

		
	}
	
	public void displaytable(Insured obj) throws SQLException {
		ResultSet rs=stmt.executeQuery("Select * FROM insured");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
	
		
	}
	
}
