package com.majesco.excep;

public class NameException extends Exception{

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Enter valid data in the fields";
	}
	

}
