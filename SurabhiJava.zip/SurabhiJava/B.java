package com.majesco;
import com.majesco.packexample.hello.*;
class B extends A{
	public static void main(String args[]){
		A a=new A();
		System.out.println(a);
	}
}