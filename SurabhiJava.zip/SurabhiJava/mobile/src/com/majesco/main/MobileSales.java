package com.majesco.main;

import java.sql.SQLException;

import com.majesco.annot.IGate_MethodInfo;
import com.majesco.dao.BusinessLogic;
import com.majesco.dao.PresentationLogic;
import com.majesco.dto.InsertMobiles;
import com.majesco.dto.MobilesPojo;
import com.majesco.dto.Operations;
import com.majesco.dto.PurchasePojo;

public class MobileSales {
	@IGate_MethodInfo(purpose = "This is the main class")
	public static void main(String[] args) throws SQLException {
	
		PurchasePojo pp;
		PresentationLogic pl=new PresentationLogic();
		Operations op=new Operations();
		//InsertMobiles im=new InsertMobiles();
		//im.insert();*/
		//im.displaytable();
		
		pp=pl.addcust();
		BusinessLogic bl=new BusinessLogic();
		pp=bl.purvalid(pp);
		if(pp==null)
			main(null);
		else{
			if(op.mobid(pp)==true)
			pp=op.insertpur(pp);
		}
		op.displaytable(pp);
		op.updatemob(pp);
		op.displaytablemob();
		
		
	}

}
