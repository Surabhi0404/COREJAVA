package com.majesco.dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.majesco.conlog.ConnectionFactory;

public class InsertMobiles {
	static Connection conn=ConnectionFactory.getConn();
	static Statement stmt;
	
	public void insert() throws SQLException {
		MobilesPojo mp=null;
		//Class.forName("oracle.jdbc.driver.OracleDriver"); to be used when you have to select driver from property files
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		//google java driver for oracle xe connection string for driver name
		//Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521", "system", "M8$tek12");
		System.out.println("Connection Established");
		stmt=conn.createStatement();
		/*boolean b=stmt.execute("create table Emp23(EMPID number(3) primary key, Ename varchar2(20))");
		System.out.println(b);
		//stmt.execute("drop table EMP23");
*/		
		//System.out.println(stmt.executeQuery("SELECT * FROM EMP23"));
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter mobileid, name, price, quantity ");
		mp=new MobilesPojo(1001,"Nokia Lumia 520",8000,20);
		int mobileid=mp.getMobileid();
		String name=mp.getName();
		float price=mp.getPrice();
		double quantity=mp.getQuantity();
		int i=stmt.executeUpdate("Insert into mobiles values("+mobileid+",'"+name+"',"+price+","+quantity+")");
		mp=new MobilesPojo(1002,"Samsung Galaxy IV",38000,40);
		mobileid=mp.getMobileid();
		name=mp.getName();
		price=mp.getPrice();
		quantity=mp.getQuantity();
		i=stmt.executeUpdate("Insert into mobiles values("+mobileid+",'"+name+"',"+price+","+quantity+")");
		mp=new MobilesPojo(1003,"Sony xperia C",15000,30);
		mobileid=mp.getMobileid();
		name=mp.getName();
		price=mp.getPrice();
		quantity=mp.getQuantity();
		i=stmt.executeUpdate("Insert into mobiles values("+mobileid+",'"+name+"',"+price+","+quantity+")");
		System.out.println("Value of i is "+i);
		conn.close();
		
	}
	
	public void displaytable() throws SQLException {
		ResultSet rs=stmt.executeQuery("Select * FROM mobiles");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
	
		
	}


}
