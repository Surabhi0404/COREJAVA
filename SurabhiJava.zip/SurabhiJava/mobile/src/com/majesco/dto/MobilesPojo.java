package com.majesco.dto;

public class MobilesPojo {
	int mobileid;
	String name;
	float price;
	double quantity;
	public MobilesPojo(int mobileid, String name, float price, double quantity) {
		super();
		this.mobileid = mobileid;
		this.name = name;
		this.price = price;
		this.quantity = quantity;
	}
	public int getMobileid() {
		return mobileid;
	}
	public void setMobileid(int mobileid) {
		this.mobileid = mobileid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public double getQuantity() {
		return quantity;
	}
	public void setQuantity(double quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "MobilesPojo [mobileid=" + mobileid + ", name=" + name
				+ ", price=" + price + ", quantity=" + quantity + "]";
	}
	

}
