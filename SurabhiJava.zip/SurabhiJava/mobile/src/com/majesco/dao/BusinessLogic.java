package com.majesco.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;


import com.majesco.conlog.ConnectionFactory;
import com.majesco.conlog.MyLogger;
import com.majesco.dto.MobilesPojo;
import com.majesco.dto.PurchasePojo;
import com.majesco.except.IPInvalidException;
//import com.majesco.logger.MyClass;

import com.majesco.main.MobileSales;

public class BusinessLogic {
	Logger logger=MyLogger.getMyLogger();
	Connection conn=ConnectionFactory.getConn();
	
	public PurchasePojo purvalid(PurchasePojo pp) throws SQLException{
		/*Statement stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM mobiles");
		boolean b = false;*/
		String cname="[A-Z][a-z]{1,20}";
		boolean cnamematch=Pattern.matches(cname, pp.getCname());
		String mailid="[A-Za-z]+[0-9]*@[a-z]+.com";
		boolean mailidmatch=Pattern.matches(mailid, pp.getMailid());
		String pno="\\d{10}";
		boolean pnomatch=Pattern.matches(pno, pp.getPhoneno());
		String mobid="\\d{4}";
		int str=pp.getMobileid();
		boolean mobidmatch=Pattern.matches(mobid, String.valueOf(str));
		/*while(rs.next()){
			String a=rs.getString("mobileid");
			if(String.valueOf(pp.getMobileid()).equalsIgnoreCase(a)){		
				 b=true;
			}
		}*/
		if(cnamematch==true&&pnomatch==true&&mobidmatch==true&&mailidmatch==true){
			return pp;
					
		}
		else{
			try {
				throw new IPInvalidException();
			} catch (IPInvalidException e) {
				// TODO Auto-generated catch block
				logger.error(e.getMessage());
				MobileSales.main(null);
			}
		return null;
			
		}
		//else return null;
		
		
	}

}
