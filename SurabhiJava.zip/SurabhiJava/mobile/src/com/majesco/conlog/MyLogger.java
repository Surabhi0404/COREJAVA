package com.majesco.conlog;


import org.apache.log4j.*;
public class MyLogger 
{	 static private Logger myLogger =  Logger.getLogger(MyLogger.class.getName( ));
	Appender myAppender;   
	SimpleLayout myLayout; 
	//Object x;
	public MyLogger()
	{ 	myLogger.setLevel(Level.INFO);  
			myLayout = new SimpleLayout();
			myAppender = new ConsoleAppender(myLayout);   
			myLogger.addAppender(myAppender);
	}
	public static Logger getMyLogger() {
		return myLogger;
	}
	public static void setMyLogger(Logger myLogger) {
		MyLogger.myLogger = myLogger;
	} 
	
	/*public void do_something( int a, float b)
	{		myLogger.info("Logged since INFO=INFO"); 
			myLogger.debug("not enabled, since DEBUG < INFO"); 
			//if (x == null)
			//{
			myLogger.error("enabled & logged ,since ERROR > INFO"); //}
	}  public static void main(String args[]) { new MyLogger().do_something(1,(float)1.2);}
  }*/
}