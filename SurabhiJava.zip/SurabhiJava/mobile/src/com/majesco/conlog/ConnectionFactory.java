package com.majesco.conlog;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Properties;

public class ConnectionFactory {
	private static Connection conn;
	private static ConnectionFactory obj=new ConnectionFactory();
	public static Connection getConn() {
		return conn;
	}
	public static void setConn(Connection conn) {
		ConnectionFactory.conn = conn;
	}
	public static ConnectionFactory getObj() {
		return obj;
	}
	public static void setObj(ConnectionFactory obj) {
		ConnectionFactory.obj = obj;
	}
	private ConnectionFactory() {
		//super();
		// TODO Auto-generated constructor stub
		Properties prop = new Properties();
	    InputStream input = null;
	  

	        try {
				input = new FileInputStream("C:/deleteme/java.prop");
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	        // load a properties file
	        try {
				prop.load(input);
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

	      

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		try {
			conn=DriverManager.getConnection(prop.getProperty("database"),prop.getProperty("dbuser"), prop.getProperty("dbpassword"));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	
	}
	


