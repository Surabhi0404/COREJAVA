package listner;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * Application Lifecycle Listener implementation class list
 *
 */
public class list implements HttpSessionListener {

    /**
     * Default constructor. 
     */
    public list() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see HttpSessionListener#sessionCreated(HttpSessionEvent)
     */
    public void sessionCreated(HttpSessionEvent arg0) {
        // TODO Auto-generated method stub
    }

	/**
     * @see HttpSessionListener#sessionDestroyed(HttpSessionEvent)
     */
    public void sessionDestroyed(HttpSessionEvent e) {
        // TODO Auto-generated method stub
    	e.getSession().setAttribute("login", false);
    	System.out.println("Session Destroyed");
    }
	
}
