package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionFactory {
	private static Connection conn;
	private static ConnectionFactory cf=new ConnectionFactory();
	private ConnectionFactory() {
		// TODO Auto-generated constructor stub
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver() );
			conn=DriverManager.getConnection("jdbc:oracle:thin:@172.17.141.83:1521:XE", "system", "M8$tek12");
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static Connection getConn() {
		return conn;
	}
	public static void setConn(Connection conn) {
		ConnectionFactory.conn = conn;
	}
	
	
}
