package filter;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import conn.ConnectionFactory;

/**
 * Servlet Filter implementation class authen
 */
public class authen extends HttpServlet implements Filter {

    /**
     * Default constructor. 
     */
    public authen() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req = (HttpServletRequest) request;
		HttpSession session = req.getSession();
		// pass the request along the filter chain
		Connection conn=ConnectionFactory.getConn();
		try {
			PreparedStatement pstm = conn.prepareStatement("select * from login where username = ? and password = ?");
			pstm.setString(1, request.getParameter("username"));
			pstm.setString(2, request.getParameter("password"));
			session.setAttribute("user",request.getParameter("username"));
			System.out.println(session.getId());
			ResultSet rs = pstm.executeQuery();
			rs.next();
			if(rs.getRow() > 0){
				session.setAttribute("login", true);
				chain.doFilter(request, response);
			}
			else{
				PrintWriter out = response.getWriter();
				out.println("<h1>Login unsuccessfull</h1>");
				out.println("<a href='/Book'>Try again</a>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
