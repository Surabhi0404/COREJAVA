package insert;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import conn.ConnectionFactory;

/**
 * Servlet implementation class insertservlet
 */

public class insertservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public insertservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		Connection conn=ConnectionFactory.getConn();
		PrintWriter out = response.getWriter();
		String id=request.getParameter("bid");
		String name=request.getParameter("bname");
		String price=request.getParameter("bprice");
		try {
			PreparedStatement pst = conn.prepareStatement("insert into book2 values(?,?,?)");
			pst.setString(1, id);
			pst.setString(2, name);
			pst.setString(3, price);
			int i = pst.executeUpdate();
		      if(i!=0){
		        out.println("<br>Record has been inserted");
		        RequestDispatcher rd=request.getRequestDispatcher("welcome1.jsp");
				rd.include(request, response);
		        
		      }
		      else{
		        out.println("failed to insert the data");
		      }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	

}
