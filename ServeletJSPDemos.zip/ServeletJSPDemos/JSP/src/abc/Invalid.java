package abc;

public class Invalid extends Exception{
	String message="ERROR OCCURED";

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.message;
	}

	public Invalid() {
		
		System.out.println(getMessage());
	}
	
}
