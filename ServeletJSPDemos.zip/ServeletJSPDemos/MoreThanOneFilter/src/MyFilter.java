
import java.io.IOException;  
import java.io.PrintWriter;  
  
import javax.servlet.*;  
  
public class MyFilter implements Filter{  
  
public void init(FilterConfig arg0) throws ServletException {
	
	System.out.println("MyFilter init called");
}  
      
public void doFilter(ServletRequest req, ServletResponse resp,  
    FilterChain chain) throws IOException, ServletException {  
          
    PrintWriter out=resp.getWriter();  
    out.print("Myfilter is invoked before <br>");  
          
    chain.doFilter(req, resp);//sends request to next resource  
          
    out.print("Myfilter is invoked after <br>");  
    }  
    public void destroy() {
    	
    	System.out.println("MyFilter destroy called");
    }  
}  