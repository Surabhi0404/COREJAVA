package abc;

public class Invalid extends Exception{
	String message="BOOK IS COSTLY! Add a cheaper value";

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return this.message;
	}

	public Invalid() {
		
		
	}
	
}
