import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.Enumeration;
public class HelloWorld extends HttpServlet{
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		
	String a=null;
	String b=null;
	String oper=null;
		PrintWriter out=res.getWriter();
		Enumeration en=req.getParameterNames();
		while(en.hasMoreElements())
		{
			Object objOri=en.nextElement();
			String param=(String)objOri;
			String value=req.getParameter(param);
			a=req.getParameter(value);
			//out.println("Parameter Name is '"+param+"' and Parameter Value is '"+value+"'");
			 value=req.getParameter(param);
			 b=req.getParameter(value);	
			 value=req.getParameter(param);
			 oper=req.getParameter(value);
			
		}		
		int result=0;
		int num1=Integer.parseInt(a);
		int num2=Integer.parseInt(b);
		if(oper.equals("+"))
			result=num1+num2;
		else if(oper.equals("-"))
			result=num1-num2;
		else if(oper.equals("*"))
			result=num1*num2;
		else if(oper.equals("/"))
			result=num1/num2;
		else 
			System.out.println("Invalid operation");
		res.setContentType("text/HTML");
		
		out.println("<HTML><BODY>");
		//out.println("<P>Hello "+myname+" "+surname+"</P>");
		out.println("<P>Num1= "+a+" Num2= "+b+" Operation= "+oper+"</P>");
		out.println("<p>Result="+result+"</p>");
		out.println("</BODY></HTML>");
		String name=req.getServerName();
		int port=req.getServerPort();
		String info=req.getServletPath();
		//String att=getAttribute(obj);
		System.out.println(name+" "+port+" "+info);
		


	}
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		doGet(req, res);

	}
}
