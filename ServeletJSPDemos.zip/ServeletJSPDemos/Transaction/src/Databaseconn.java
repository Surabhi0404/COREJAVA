import javax.servlet.*;
import javax.servlet.http.*;



import java.io.*;
import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class Databaseconn extends HttpServlet{

	Connection conn=null;
	
		
		
	
	
	public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException{
		 try {
			 DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			 
			 conn = DriverManager.getConnection ("jdbc:oracle:thin:hr/hr@172.17.141.83:1521:XE", "system", "M8$tek12");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 System.out.println("Connection is : "+conn);
		RequestDispatcher rd=null;
		String str1=req.getParameter("username");
		String str2=req.getParameter("password");
		PrintWriter pw=res.getWriter();
		pw.println("<html><body>");
		try {
			PreparedStatement pst=conn.prepareStatement("select * from login where username=? and password=?");
			pst.setString(1,str1);
			pst.setString(2,str2);
			ResultSet rs=pst.executeQuery();
			rs.next();
			int i=rs.getRow();
			if(i>0)
			{
				pw.println("<p>successfull login</p>");
				rd=req.getRequestDispatcher("Form.html");
				rd.include(req, res);
				
			}
			else{ 
				pw.println("<p>UNsuccessfull login</p>");
				rd=req.getRequestDispatcher("Login.html");
				rd.include(req, res);
				
			}
			pw.println("</body> </html>");
		} 
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
