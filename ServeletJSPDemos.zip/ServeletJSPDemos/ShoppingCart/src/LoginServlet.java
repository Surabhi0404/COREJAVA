

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;



public class LoginServlet extends HttpServlet {

	HashMap<String,String> logindet;
 
	public void init()
	{
		logindet=new HashMap<String,String>();
		logindet.put("ram", "aram");
		logindet.put("shyam", "ashyam");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String r = request.getParameter("invalidatesession");
		if(r.equals("true"))
		{
			HttpSession s = request.getSession();
			
			s.setAttribute("logout",true);
			s.invalidate();
			PrintWriter out = response.getWriter();
		    out.println("<html><head>");
		    out.print("<h1>Logged Out!<h1></head>");
		    out.println("<body>");
			
			out.println("<h3>you have successfully logged out</h3>");
			out.println("<a href='login.jsp'>Goto Login Page</a>");
			
			out.println("</body></html>");
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	   
		
		  String user = request.getParameter("username");
          String pass = request.getParameter("password");
          
          PrintWriter out = response.getWriter();
          out.println("<html><body>");
          
          String url = null;
          
          boolean b1 = logindet.containsKey(user);
          if(b1==true)
          {
        	  String p = logindet.get(user);
        	  if(p.equals(pass))
           	  {
        		  //login successful
        		  
                 HttpSession s = request.getSession();		  
        		  s.setAttribute("login",true);
        		  
        		 RequestDispatcher rd =  request.getRequestDispatcher("shop.jsp");
                 rd.forward(request,response);
        		
        		 
        		  
        	  }
        	  else
        	  {
        		  //login not successful
        	       	     
        		 out.println("<p>login is not successful!</p>");
        		 out.println("<a href='login.jsp'>Re-Login</a>");
        		  
        	  }
          }
          else 
          {
        	  //login not successful
        		 out.println("<p>login is not successful!</p>");
        		 out.println("<a href='login.jsp'>Re-Login</a>");
          }
          
		 out.println("</body></html>");
		}
	
	

}
