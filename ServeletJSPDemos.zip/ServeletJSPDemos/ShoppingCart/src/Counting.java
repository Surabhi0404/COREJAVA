import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import javax.servlet.*;


public class Counting implements HttpSessionListener{

	static int count=0;
	public void sessionCreated(HttpSessionEvent e) {
	
		System.out.println("Session Created"+(++count));
	}

	public void sessionDestroyed(HttpSessionEvent e) {
		
		System.out.println("Session Destroyed"+(--count));
		
		Boolean b = (Boolean)e.getSession().getAttribute("logout");
		
		if(b!=null && b!=true )
		{
			
			  ServletContext sc = e.getSession().getServletContext();
			  sc.setAttribute("timedout",true);
			
		}
				
	}
	

}
