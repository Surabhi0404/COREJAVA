

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;

/**
 * Servlet implementation class ShoppingCart
 */

public class ShoppingCart extends HttpServlet {
	
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	   
		response.setContentType("text/html");
	     PrintWriter out = response.getWriter();
	      
		
		/*Following things will be done by container as part of getSession method:-
		 * 1) it will check if sessionid is present in request (obj), if yes 
		 *    it means it its repeated request from old client 
		 *    if No, then its new reqst frm new client 
		 * 2) if its new client, getSession method will create a new Session object 
		 *    mapped to new unique sessionid and return that Session object.  
		 * 3) if its old(req has sessionid) client then instead of creating new session 
		 *    object it will return already existing session object corresponding to the 
		 *    sessionid that has come as part of the request
		 * 4) It will also implicitly send back the sessionid in response    
		 */ 
		     HttpSession s = request.getSession();
		     s.setMaxInactiveInterval(10);
		     
		     Boolean login = (Boolean)s.getAttribute("login");
			 	if(login==null || login!=true)
			 	{
			 		System.out.println("not logged in");
			 		request.getRequestDispatcher("login.jsp").forward(request,response);
			 	}
			 		
		     
		     
		     Boolean b1= (Boolean)this.getServletContext().getAttribute("timedout");
		     if(b1!=null && b1==true)
		     {
		     	request.getRequestDispatcher("login.jsp").forward(request,response);
		     }
		     
		   
		   
		 	
		     String b = request.getParameter("bookname");
		
		     ArrayList<String> cart =(ArrayList<String>)s.getAttribute("shopcart");
		     if(cart==null)  //if shopcart value is null it means its new session object
		     {
		    	 cart = new ArrayList<String>();
		    	 cart.add(b);
		    	 s.setAttribute("shopcart",cart);
		     }
		     else
		     {
		    	   cart.add(b);
		     }
		     
		      Iterator<String> it =cart.iterator();
		      
		      
		      out.println("<html><body>");
		      out.println("<h3>Shopping Cart: Book List</h3>");
		      
		      out.println("<ul>");
		      
		      while(it.hasNext())
		      {
		    	  out.println("<li>"+it.next()+"</li>");
		      }
		      out.println("</ul>");
		      
		      String u = "shop.jsp";
		      
		      u = response.encodeURL(u);
		      
		      out.println("<a href='"+u+"'>Goto Home Page</a>");
		      
		     
		      out.println("<a href='login?invalidatesession=true'>Logout</a>");
		      
		      
		      out.println("</body></html>");
		      
		
	}
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}


}
