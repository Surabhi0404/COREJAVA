package com.majesco.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;


import com.majesco.conlog.ConnectionFactory;
import com.majesco.conlog.MyLogger;

import com.majesco.dto.Operations;
import com.majesco.dto.Pojo;


//import com.majesco.logger.MyClass;



public class BusinessLogic {
	Logger logger=MyLogger.getMyLogger();
	
	public Pojo blinsert(Operations op, Pojo pp){
		try {
			pp=op.insertpojo(pp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage()); //Logs onto Console
		}
		return pp;
	}
	/*public BusinessLogic(Operations op, Pojo pp) {
		// TODO Auto-generated constructor stub
		try {
			op.insertpojo(pp);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.error(e.getMessage()); //Logs onto Console
		}
	}*/


	//Connection conn=ConnectionFactory.getConn();
	
}
