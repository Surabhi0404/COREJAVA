package com.majesco.dao;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.majesco.annot.IGate_MethodInfo;
import com.majesco.dto.Operations;
import com.majesco.dto.Pojo;


public class PresentationLogic {
		@IGate_MethodInfo(purpose ="Calls the display method")
		//Operations op;
		public void display(Operations op, Pojo pp) throws SQLException {
			op.displaytable(pp);
			
		
			// TODO Auto-generated constructor stub
			
		}
	

	

}
