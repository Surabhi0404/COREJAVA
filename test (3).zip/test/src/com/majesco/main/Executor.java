package com.majesco.main;

import java.sql.SQLException;

import com.majesco.annot.IGate_MethodInfo;
import com.majesco.dao.BusinessLogic;
import com.majesco.dao.PresentationLogic;


import com.majesco.dto.Operations;
import com.majesco.dto.Pojo;


public class Executor {
	@IGate_MethodInfo(purpose = "This is the main class")
	public static void main(String[] args) throws SQLException {
		Pojo pp=new Pojo();
		Operations op=new Operations();
		op.select(pp);
		PresentationLogic plogic=new PresentationLogic();
		BusinessLogic blogic=new BusinessLogic();
		blogic.blinsert(op, pp);
		plogic.display(op, pp);
	
		
		
	}

}
