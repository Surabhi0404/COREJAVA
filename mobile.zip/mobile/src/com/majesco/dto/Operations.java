package com.majesco.dto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.majesco.conlog.ConnectionFactory;

public class Operations {
	Connection conn=ConnectionFactory.getConn();
	static Statement stmt;
	public PurchasePojo insertpur(PurchasePojo pp) throws SQLException{
		PreparedStatement pst=conn.prepareStatement("Insert into purchasedetails values (?,?,?,?,sysdate,?)");
		pst.setInt(1, pp.getPurchaseid());
		pst.setString(2, pp.getCname());
		pst.setString(3, pp.getMailid());
		pst.setString(4,pp.getPhoneno());
		//pst.setString(, pp.getPurchasedate());
		pst.setInt(5, pp.getMobileid());
		int i=pst.executeUpdate();
		return pp;
	}
	
	public void displaytable(PurchasePojo obj) throws SQLException {
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM purchasedetails");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
	
		
	}
	public void displaytablemob() throws SQLException {
		stmt=conn.createStatement();
		ResultSet rs=stmt.executeQuery("Select * FROM mobiles");
		ResultSetMetaData rsmd=rs.getMetaData();
		int cols=rsmd.getColumnCount();
		for (int i = 1; i <=cols; i++) {
			System.out.print(rsmd.getColumnName(i)+"\t");
		}
		System.out.println();
		System.out.println("=============================================");
		while (rs.next()) {
			for (int i = 1; i <=cols; i++) {
				System.out.print(rs.getString(i)+"\t");
				
			}
			System.out.println();
		}
	
		
	}
	public boolean mobid(PurchasePojo pp) throws SQLException{
		stmt=conn.createStatement();
		int i=stmt.executeUpdate("Select * FROM mobiles where mobileid="+pp.getMobileid());
		if(i>0){
			conn.commit();
			return true;}
		else return false;
	}
	public void updatemob(PurchasePojo pp) throws SQLException{
		stmt=conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs=stmt.executeQuery("Select quantity FROM mobiles WHERE mobileid="+pp.getMobileid());
		String quantity=null;
		while(rs.next()){
		quantity=rs.getString("quantity");
		int i=Integer.parseInt(quantity);
		i=i-1;
		System.out.println(i);
		String qty=String.valueOf(i);
		System.out.println(qty);
		rs.moveToCurrentRow();
		rs.updateString(1,qty);
		rs.updateRow();
		
		System.out.println("a");
		}
		conn.commit();
		
		
	
	}

}
