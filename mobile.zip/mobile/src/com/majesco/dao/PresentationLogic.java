package com.majesco.dao;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.majesco.dto.MobilesPojo;
import com.majesco.dto.PurchasePojo;

public class PresentationLogic {
	Scanner sc;
		public PurchasePojo addcust(){
		System.out.println("Insert purchaseid, cname, mailid, phoneno, mobileid");
		//PurchasePojo pp=new PurchasePojo();
		sc=new Scanner(System.in);
		int purchaseid=sc.nextInt();
		String cname=sc.next();
		String mailid=sc.next();
		String phoneno=sc.next();
		int mobileid=sc.nextInt();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy");  
		String purchasedate=formatter.format(new Date());
		
		PurchasePojo pp=new PurchasePojo(purchaseid, cname, mailid, phoneno, purchasedate, mobileid);
		return pp;
	}

}
