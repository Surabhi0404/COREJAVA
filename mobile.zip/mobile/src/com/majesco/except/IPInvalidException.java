package com.majesco.except;

import com.majesco.main.MobileSales;

public class IPInvalidException extends Exception{

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "Add valid data in fileds";
		
	}
	

}
